1. adjust TST implementation, using root[26] instead of root;
